const { app, BrowserWindow, Tray, Menu, nativeImage, powerSaveBlocker } = require("electron");
const path = require("path");

// Let bells play without a user click, and keep timers running in the background.
app.commandLine.appendSwitch("autoplay-policy", "no-user-gesture-required");
app.commandLine.appendSwitch("disable-renderer-backgrounding");
app.commandLine.appendSwitch("disable-background-timer-throttling");

let win, tray, quitting = false;
const icon = nativeImage.createFromPath(path.join(__dirname, "build", "icon.png"));

if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", () => { if (win) { win.show(); win.focus(); } });

function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 820, minWidth: 420, minHeight: 600,
    title: "BellWave", icon, autoHideMenuBar: true, backgroundColor: "#0d1021",
    webPreferences: { backgroundThrottling: false, contextIsolation: true, nodeIntegration: false }
  });
  win.setMenu(null);
  win.loadFile("index.html");
  // Closing the window hides it to the tray so bells keep ringing.
  win.on("close", (e) => { if (!quitting) { e.preventDefault(); win.hide(); } });
}

function buildTray() {
  tray = new Tray(icon.resize({ width: 16, height: 16 }));
  tray.setToolTip("BellWave – school bell system");
  const menu = () => Menu.buildFromTemplate([
    { label: "Open BellWave", click: () => { win.show(); win.focus(); } },
    { label: "Start with Windows", type: "checkbox",
      checked: app.getLoginItemSettings().openAtLogin,
      click: (m) => app.setLoginItemSettings({ openAtLogin: m.checked, args: ["--hidden"] }) },
    { type: "separator" },
    { label: "Quit (bells will stop)", click: () => { quitting = true; app.quit(); } }
  ]);
  tray.setContextMenu(menu());
  tray.on("click", () => { win.show(); win.focus(); });
}

app.whenReady().then(() => {
  powerSaveBlocker.start("prevent-app-suspension");
  // First run: start with Windows by default (school PCs should ring after a reboot).
  if (app.isPackaged && !app.getLoginItemSettings().wasOpenedAtLogin && !require("fs").existsSync(path.join(app.getPath("userData"), ".init"))) {
    app.setLoginItemSettings({ openAtLogin: true, args: ["--hidden"] });
    require("fs").writeFileSync(path.join(app.getPath("userData"), ".init"), "1");
  }
  createWindow();
  buildTray();
  if (process.argv.includes("--hidden")) win.hide();
});
app.on("before-quit", () => { quitting = true; });
