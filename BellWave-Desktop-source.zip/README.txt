BellWave Desktop - build the Windows installer
==============================================
Option A - on any Windows PC (5 minutes)
 1. Install Node.js LTS from https://nodejs.org
 2. Open this folder in Command Prompt and run:
        npm install
        npm run dist
 3. Your installer is dist\BellWave Setup 1.0.0.exe

Option B - no tools on your PC
 Upload this folder to a GitHub repository. The included workflow
 (.github/workflows/build.yml) builds the installer for you; download it
 from the Actions tab > Artifacts.

Try it without installing:   npm install  then  npm start

What the installed app does
 - Arms itself on launch, so bells ring with no clicks
 - Closing the window hides it to the system tray; bells keep ringing
 - Starts with Windows (toggle in the tray menu)
 - Keeps the PC from suspending the app; also set Windows Power & Sleep to "Never"
 - Settings are saved per Windows user; use Export/Import to copy to other PCs
